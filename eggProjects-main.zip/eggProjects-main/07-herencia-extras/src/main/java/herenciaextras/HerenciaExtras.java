package herenciaextras;

import herenciaextras.services.AlquilerPuertoService;

/**
 *
 * @author lucas
 */
public class HerenciaExtras {

    public static void main(String[] args) {
        AlquilerPuertoService sv = new AlquilerPuertoService();
        sv.alquilarBarco();
    }
}
