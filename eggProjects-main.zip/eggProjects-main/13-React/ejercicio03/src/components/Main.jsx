import Hijo from "./Hijo";

const Main = () => {
  return (
    <main>
      <Hijo nombre="Lucas"/>
      <Hijo nombre="Juan"/>
    </main>
  );
};

export default Main;