const Hijo = (props) => {
  return <p>Hola {props.nombre}</p>;
};

export default Hijo;