const Footer = () => {
  return (
    <footer className="mt-auto">
      <p>Footer.</p>
    </footer>
  );
};

export default Footer;