const Main = () => {
  return (
    <main className="px-3">
      <h2>Soy el Main</h2>
    </main>
  );
};

export default Main;