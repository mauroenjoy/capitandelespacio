import './App.css'
import FunctionalComp from './functionalComp';

function App() {
  return (
    <>
      <div>
        <FunctionalComp />
      </div>
    </>
  )
}

export default App
