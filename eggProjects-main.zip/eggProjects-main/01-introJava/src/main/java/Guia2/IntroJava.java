
package Guia2;

import java.util.Scanner;

//@author bassman_55

public class IntroJava {

     public static void main(String[] args) {
        
        //variable scanner para leer datos del usuario
        Scanner leer = new Scanner(System.in);
/*
        //variable string que se utilizará para los datos
        String nombre;
        //mostramos un msj por pantalla
        System.out.println("Ingrese su nombre");
        //guardamos en nombre lo que leemos en el ingreso de datos
        nombre = leer.next();
        System.out.println("Hola Mundo! soy " +nombre+ " y estoy programando en Java!");
        */
//---------------------------------------------------------------------------------------------------------------
        /*
        Ejercicio de la guía T de definir diferentes variables
         
        int numero;
        boolean ver;
        String nomb2;
        float decimal;
        */
    
    }
    
}

