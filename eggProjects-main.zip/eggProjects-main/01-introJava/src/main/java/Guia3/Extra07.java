package Guia3;

import java.util.Scanner;

/** EJ 7 - Realice un programa que calcule y visualice el valor máximo, el valor mínimo y el promedio de n números (n>0). 
        El valor de n se solicitará al principio del programa y los números serán introducidos por el usuario.
        Realice dos versiones del programa, una usando el bucle “while” y otra con el bucle “do - while”.*/

public class Extra07 {

    public static void main(String[] args) {
        
        Scanner read = new Scanner(System.in).useDelimiter("\n");

        System.out.println("Ingrese la cantidad");
        int n = read.nextInt();
        
        
        
        
    }
    
}
