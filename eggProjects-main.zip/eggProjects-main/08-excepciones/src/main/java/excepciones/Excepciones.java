package excepciones;

/**
 *
 * @author lucas
 */
public class Excepciones {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
