package herencia.entities;

/**
 *
 * @author lucas
 */
public interface calculosFormas {
    double PI = Math.PI;
    double calcularArea();
    double calcularPerimetro();
}
