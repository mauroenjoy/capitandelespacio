package herencia.entities;

public class Implementacion {
    
}
