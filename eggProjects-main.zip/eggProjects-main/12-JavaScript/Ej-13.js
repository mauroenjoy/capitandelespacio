/*Crear un objeto persona, con las propiedades nombre, edad, sexo ('H' hombre, 'M' mujer, 
'O' otro), peso y altura. A continuación, muestre las propiedades del objeto JavaScript*/

let persona = {nombre: "Lucas",edad: 31,sexo: "H",peso: null,altura: null}

console.log(`Nombre: ${persona.nombre}
Edad: ${persona.edad}
Sexo: ${persona.sexo}
Peso: ${persona.peso}
Altura: ${persona.altura}`)