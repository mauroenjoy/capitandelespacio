/*Escribir una función flecha de JavaScript que reciba un argumento y retorne el tipo de 
dato*/

let tipo = (x) => typeof(x)