package claseServicio.services;

import java.util.Scanner;

public class CafeteraServicio {
    
    static Scanner read = new Scanner(System.in);
    
    public void llenarCafetera(){
        
    }

}
